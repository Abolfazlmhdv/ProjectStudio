package com.example.canvasapp

import com.example.canvasapp.AndroidUtilites.dp

import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout

object Helper {

    const val MATH_PARENT = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP_CONTENT = ViewGroup.LayoutParams.WRAP_CONTENT



    fun createFrame(width : Int, height : Int, gravity: Int = Gravity.NO_GRAVITY, leftMargin: Int, topMargin: Int, rightMargin: Int, bottomMargin: Int) :
            FrameLayout.LayoutParams {
        val parmsFame = FrameLayout.LayoutParams(dp(width), dp(height))
        parmsFame.setMargins(dp(leftMargin), dp(topMargin), dp(rightMargin), dp(bottomMargin))
        parmsFame.gravity = gravity
        return parmsFame
    }

}