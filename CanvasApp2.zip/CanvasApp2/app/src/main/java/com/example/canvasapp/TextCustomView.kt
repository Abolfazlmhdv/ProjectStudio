package com.example.canvasapp

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class TextCustomView(context: Context) : View(context) {

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.BLACK
        paint.textSize = 15f
        val text: String = "Hello"
        val centerX = width / 2f
        val centerY = height / 2f

        canvas.drawText(text, centerX, centerY, paint)
    }

}