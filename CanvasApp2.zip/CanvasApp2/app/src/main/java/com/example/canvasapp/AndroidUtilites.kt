package com.example.canvasapp

import android.content.res.Resources
import android.graphics.Typeface

object AndroidUtilites {

    fun dp(value : Number) : Int {
        val dpi = Resources.getSystem().displayMetrics.density
        return (value.toFloat() * dpi + 0.5f).toInt()
    }
    fun sp (value: Number) : Int {
        val sizeText = Resources.getSystem().displayMetrics.scaledDensity
        return (value.toFloat() * sizeText + 0.5f).toInt()
    }

        fun bold() : Typeface = Typeface.create("bold", Typeface.BOLD)
}